source("http://bioconductor.org/biocLite.R")
# biocLite("GenomicRanges")
# biocLite("AnnotationHub")
# biocLite("rtracklayer")
# biocLite('BSgenome.Hsapiens.UCSC.hg38')
library("GenomicRanges")
library("AnnotationHub")
library('BSgenome.Hsapiens.UCSC.hg38')
library(Rsamtools)
#BiocManager::install('TxDb.Hsapiens.UCSC.hg38.knownGene')
#BiocManager::install('BSgenome.Hsapiens.UCSC.hg38')
library(TxDb.Hsapiens.UCSC.hg38.knownGene)

txdb = TxDb.Hsapiens.UCSC.hg38.knownGene # abbreviate


ghs = genes(txdb)

upstream = 1000

chrs = unlist(lapply(1:22, function(x)paste0('chr',x)))
ghs = ghs[seqnames(ghs)%in%chrs]
proms = promoters(ghs, upstream=upstream , downstream=upstream)
proms  = trim(proms)
proms = proms[seqnames(proms)%in%chrs]
# excluding promoters without full range for now
proms = proms[width(proms)>=2*upstream]

# saving sequences as fasta file

promoter_seqs = getSeq(Hsapiens, proms)
names(promoter_seqs) = proms$gene_id
##DO NOT reverseComplement if promter strand is -, it's in the right format for the beedtools compute matrix!

#promoter_seqs[which(strand(proms)=='-')] = reverseComplement(promoter_seqs[which(strand(proms)=='-')])
dir.create(paste0('~/aylin/projects/data/genomes/human/hg19/Promoter_',upstream))

writeXStringSet(promoter_seqs, paste0('~/aylin/projects/data/genomes/human/hg38/Promoter_',upstream,'/TSS.fa'))

export.bed(ghs[ghs$gene_id %in% proms$gene_id], paste0('~/aylin/projects/data/genomes/human/hg38/TSS_annotation.bed'))
